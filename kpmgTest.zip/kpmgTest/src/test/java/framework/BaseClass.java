package framework;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class BaseClass {

    protected WebDriver driver;
    public static Properties properties;

    @Parameters({"browser"})
    @BeforeClass
    public void suiteSetup(@Optional("null") String browser) throws Exception {

        properties = new Properties();
        properties.load(new FileReader(new File("./src/test/resources/Environment.properties")));

        if (browser == null) {
            browser = properties.getProperty("browser.name");
        }
        Reporter.log("Browser name is " + browser);
        //Browser configuration - can add more browsers and remote driver here
        if (browser.equalsIgnoreCase("Firefox")) {
            WebDriverManager.firefoxdriver().setup(); //can also use set property method for browser executables
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("Chrome")) {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            Map<String, Object> prefs = new HashMap<String, Object>();
            prefs.put("credentials_enable_service", false);
            prefs.put("profile.password_manager_enabled", false);
            options.setExperimentalOption("prefs", prefs);
            options.addArguments("--disable-notifications");
            options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
            driver = new ChromeDriver(options);
        } else if (browser.equalsIgnoreCase("IE")) {
            WebDriverManager.iedriver().setup();
            driver = new InternetExplorerDriver();
        } else {
            throw new RuntimeException("Browser type not set");
        }

        //Setting implicit wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        //load URL
        loadBaseUrl();

    }

    public void loadBaseUrl() {
        String url = properties.getProperty("app.url");
        driver.get(url);

    }


    @AfterMethod
    public void screenshotAndDeleteCookies(ITestResult testResult) throws IOException {
        //Taking screenshot in case of failure
        if (testResult.getStatus() == ITestResult.FAILURE) {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String fileWithPath = "errorScreenshots/" + testResult.getName() + "-" + System.currentTimeMillis() + ".jpg";
            FileUtils.copyFile(scrFile, new File("./test-output/" + fileWithPath));
            Reporter.setCurrentTestResult(testResult);
            Reporter.log("<a href=\"" + fileWithPath + "\" target=\"_blank\">screenshot</a><br/>", true);


        }


    }


    @AfterClass
    public void suiteTearDown() {

        driver.quit();
    }

}

