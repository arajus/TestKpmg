package framework;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.NoSuchElementException;
import java.util.function.Function;

public class WrapperClass {
    WebDriver driver ;
    WebDriverWait wait;
    int shortWait;
    int longWait;

    protected WrapperClass(WebDriver driver){
        this.driver =driver;
        shortWait= Integer.parseInt(BaseClass.properties.getProperty("shortWait"));
        longWait= Integer.parseInt(BaseClass.properties.getProperty("longWait"));
        wait= new WebDriverWait(driver, longWait);

    }

    public void click(By by) {


        wait.ignoring(NoSuchElementException.class);
        wait.ignoring(ElementClickInterceptedException.class);
        wait.until(new Function<WebDriver, Boolean>() {

            @Override
            public Boolean apply(WebDriver driver) {
                // TODO Auto-generated method stub
                new Actions(driver).moveToElement(driver.findElement(by)).click().build().perform();
                return true;
            }
        });
    }

    public void sendKeys(By by, String value) {
        wait.until(new Function<WebDriver, Boolean>() {

            @Override
            public Boolean apply(WebDriver driver) {
                // TODO Auto-generated method stub
                driver.findElement(by).sendKeys(value);
                return true;
            }
        });
    }



}
