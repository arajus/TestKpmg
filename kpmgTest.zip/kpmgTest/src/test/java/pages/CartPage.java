package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import java.util.List;

public class CartPage extends CommonPage {

    public CartPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "continue-shopping")
    WebElement btn_contShpng;

    @FindBy(xpath = "//div[normalize-space()='Sauce Labs Backpack']")
    WebElement firstProductTitle;

    @FindBy(xpath = "//div[@class='inventory_list']//div[1]//div[2]//div[2]//div[1]")
    WebElement firstProductPrice;

    @FindBys({
            @FindBy(className = "inventory_item_name")
    })
    private List<WebElement> productNames;


    @FindBy(name = "checkout")
    WebElement btn_checkout;

    public String getFirstProductTitleOnCartPage() {
        return firstProductTitle.getText();
    }

    public void clickOnContineShopping() {
        btn_contShpng.click();
        Reporter.log("Clicked on Continue shopping <br/>", true);
    }

    public void gettheProductNamesFromCartPage() {
        Reporter.log("Product(s) available on Cart is ",true);
        for (WebElement webElement : productNames) {
            String name = webElement.getText();
            Reporter.log(name +"<br/>",true);
        }
    }

    public void clickOnCheckout() {
        btn_checkout.click();
        Reporter.log("User clicked on Checkout button <br/>", true);
    }

}
