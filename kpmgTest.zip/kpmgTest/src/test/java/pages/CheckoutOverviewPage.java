package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import java.util.List;

public class CheckoutOverviewPage extends CommonPage {

    public CheckoutOverviewPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(className = "summary_subtotal_label")
    WebElement summaryTotal;

    By btn_finish = By.name("finish");

    @FindBys({
            @FindBy(className = "inventory_item_price")
    })
    private List<WebElement> prices;


    public float getTotalValueWithoutTax() {
        float f = Float.parseFloat(summaryTotal.getText().replaceAll(".*?([\\d.]+).*", "$1"));
        Reporter.log("Total Price for two products showing on cart page excluding VAT is "+f +"<br/>");
        return f;
    }
    public float getSumOfEachProductPrice() {
        float sum = 0;
        for(WebElement individualPrices:prices)
        {
            String s = individualPrices.getText().replace("$", "");
            float f = Float.parseFloat(individualPrices.getText().replaceAll(".*?([\\d.]+).*", "$1"));
            Reporter.log("Individual product price is "+ f +"<br/>");
            sum = sum + f;
        }
        Reporter.log("Sum of Individual two products is: " + sum);
        return sum;

    }

    public void clickOnFinish(){
        click(btn_finish);
        Reporter.log("Clicked on FINISH at the ordr page",true);
    }

}


