package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class LoginPage extends CommonPage {

    public LoginPage(WebDriver driver){
        super(driver);
        PageFactory.initElements(driver, this);
    }
    @FindBy(name ="user-name")
    WebElement txtbox_UserName;

    @FindBy(name="password")
    WebElement txtbox_Password;

    @FindBy(name="login-button")
    WebElement btn_Login;

    public void entrUserName(String usrName){
        txtbox_UserName.clear();
        txtbox_UserName.sendKeys(usrName);
        Reporter.log("Username Entered successfully <br/>",true);
    }

    public void entrPassWord(String pass){
        txtbox_Password.clear();
        txtbox_Password.sendKeys(pass);
        Reporter.log("Password Entered successfully <br/>",true);
    }

    public void clickOnLoginBtn(){
        btn_Login.click();
        Reporter.log("User clicked on Login button <br/>",true);
    }

    public void login(String usrName, String pass){
        this.entrUserName(usrName);
        this.entrPassWord(pass);
        this.clickOnLoginBtn();
    }

}
