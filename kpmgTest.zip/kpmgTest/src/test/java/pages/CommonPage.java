package pages;

import framework.WrapperClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class CommonPage extends WrapperClass {

    CommonPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(className="title")
    WebElement title;

    public String getTitle(){
        Reporter.log("Title of the page is " + title.getText() +"<br/>");
        return	title.getText();
    }
}
