package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class FinalPage extends CommonPage {

    public FinalPage(WebDriver driver){
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(className="complete-header")
    WebElement thanksMsg;

    @FindBy(id="react-burger-menu-btn")
    WebElement menuBtn;

    @FindBy(xpath="//a[normalize-space()='Logout']")
    WebElement logOutBtn;

    public String orderMsg(){
        return	thanksMsg.getText();
    }

    public void clickOnMenu(){
        menuBtn.click();
        Reporter.log("User clicked on Menu button <br/>",true);
    }

    public void clickOnLogoutBtn(){
        logOutBtn.click();
        Reporter.log("User clicked on Logout button <br/>",true);
    }

    public void logout(){
        this.clickOnMenu();
        this.clickOnLogoutBtn();
    }

}
