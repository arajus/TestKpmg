package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class ProductsPage extends CommonPage {

    public ProductsPage(WebDriver driver){
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath="//a[@class='shopping_cart_link']")
    WebElement cart;

    @FindBy(xpath="//span[@class='shopping_cart_badge']")
    WebElement itemsInCart;

    @FindBy(name="add-to-cart-sauce-labs-backpack")
    WebElement firstProduct;

    @FindBy(xpath="//div[normalize-space()='Sauce Labs Backpack']")
    WebElement firstProductTitle;

    @FindBy(xpath="//div[@class='inventory_list']//div[1]//div[2]//div[2]//div[1]")
    WebElement firstProductPrice;

    @FindBy(name="add-to-cart-sauce-labs-bike-light")
    WebElement secondProduct;

    @FindBy(xpath="//div[normalize-space()='Sauce Labs Bike Light']")
    WebElement secondProductTitle;

    @FindBy(xpath="//div[@id='inventory_container']//div[2]//div[2]//div[2]//div[1]")
    WebElement secondProductPrice;


    public void clickOnCart(){
        	cart.click();
    }

    public String getCartCount(){
        Reporter.log("Product count is " + cart.getText() +"<br/>",true);
        return	cart.getText();
    }

    public String getFirstProductTitle(){
        return	firstProductTitle.getText();
    }

    public void addFirstProductToCart(){
        firstProduct.click();
        Reporter.log("User Clicked on First product to add to cart <br/>",true);
    }

    public void addSecondProductToCart(){
        secondProduct.click();
        Reporter.log("User Clicked on Second product to add to cart <br/>",true);
    }

    public String getSecondProductTitle(){
        return	secondProductTitle.getText();
    }

    public String getSecondProductPrice(){
        return	secondProductPrice.getText();
    }
}
