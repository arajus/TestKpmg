package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class CheckoutCartPage extends CommonPage {

    public CheckoutCartPage(WebDriver driver){
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(name="firstName")
    WebElement firstName;

    @FindBy(name="lastName")
    WebElement lastName;

    @FindBy(name="postalCode")
    WebElement postalCode;

    @FindBy(name="continue")
    WebElement btn_continue;

    public void entrfirstName(String fstName){
        firstName.clear();
        firstName.sendKeys(fstName);
        Reporter.log("FirstName is entered on Checkout Overview Page <br/>",true);
    }

    public void entrlastName(String lstName){
        lastName.clear();
        lastName.sendKeys(lstName);
        Reporter.log("LastName is entered on Checkout Overview Page <br/>",true);
    }

    public void entrPostCode(String zipCode){
        postalCode.sendKeys(zipCode);
        Reporter.log("Post/ZIP code is entered on Checkout Overview Page <br/>",true);
    }

    public void clickOnContine(){
        btn_continue.click();
        Reporter.log("Clicked on continue at the ordr page <br/>",true);
    }

    public void enterUserDetails(String firstName, String lastName, String postCode){
        this.entrfirstName(firstName);
        this.entrlastName(lastName);
        this.entrPostCode(postCode);
    }

}
