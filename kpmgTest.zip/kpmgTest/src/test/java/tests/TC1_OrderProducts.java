package tests;

import framework.BaseClass;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.*;
import util.ExcelUtil;

public class TC1_OrderProducts extends BaseClass {

    LoginPage login;
    ProductsPage productsPage;
    CartPage cartPage;
    CheckoutCartPage checkoutCartPage;
    CheckoutOverviewPage checkoutOverviewPage;
    FinalPage finalPage;

    @Test(priority = 1, dataProvider = "credentials")
    public void loginToApp(String userName, String passWord) throws InterruptedException {
        login = new LoginPage(driver);
        //login to application
        login.login(userName, passWord);

        // go the products page
        productsPage = new ProductsPage(driver);
        //Verify successful login
        String loginPageTitle = productsPage.getTitle();
        Assert.assertTrue(loginPageTitle.toLowerCase().contains("products"));
        Reporter.log("Logged in successfully <br/>", true);
    }

    @Test(priority = 2, dataProvider = "userInfo", dependsOnMethods = "loginToApp")
    public void addProductsToCart(String fn, String ln, String pc) {
        //Verify CART is empty for the first time
        Assert.assertTrue(productsPage.getCartCount().isEmpty(), "Cart is not empty");
        Reporter.log("Cart is empty <br/>", true);

        //Add First product to Cart & verify the product added to cart or not
        productsPage.addFirstProductToCart();
        Assert.assertEquals(Integer.parseInt(productsPage.getCartCount()), 1);
        Reporter.log("First Product is added to cart successfully <br/>", true);

        //click on CART
        productsPage.clickOnCart();

        //Create Cart Page object
        cartPage = new CartPage(driver);
        //click on Continue shopping
        cartPage.clickOnContineShopping();
        //add second product to CART
        productsPage.addSecondProductToCart();

        //Verify if the second product added to cart & cart is not empty
        //navigate to basket products & verify products are there
        productsPage.clickOnCart();
        Assert.assertEquals(Integer.parseInt(productsPage.getCartCount()),2);
        Reporter.log("Two Products are added to cart successfully <br/>", true);

        //Print the Product Names from Cart Page
        cartPage.gettheProductNamesFromCartPage();

        //click on checkout
        cartPage.clickOnCheckout();
        //enter the details at checkout CART page
        //Create CheckoutCart Page object
        checkoutCartPage = new CheckoutCartPage(driver);
        checkoutCartPage.enterUserDetails(fn, ln, pc);
        checkoutCartPage.clickOnContine();
    }

    @Test(priority = 3, dependsOnMethods = "addProductsToCart")
    public void verifySumOfTheProducts() throws InterruptedException {
        //Validate the total amount before tax is equalant to total amnt of each product
        //Create CheckoutCart Page object
        checkoutOverviewPage = new CheckoutOverviewPage(driver);

        float sumOfTwoIndividualPrdAtCOPage = checkoutOverviewPage.getSumOfEachProductPrice();
        float totalPriceAtChkOvervwPageWOTax = checkoutOverviewPage.getTotalValueWithoutTax();
        Assert.assertEquals(sumOfTwoIndividualPrdAtCOPage, totalPriceAtChkOvervwPageWOTax);
        Reporter.log("Sum of Individual two products is equalant to Total price without tax <br/>", true);

        //click on Finish Button
        checkoutOverviewPage.clickOnFinish();
    }

    @Test(priority = 4, dependsOnMethods = "verifySumOfTheProducts")
    public void verifyOrderAndLogOut() {
        //validate order
        //Create CheckoutCart Page object
        finalPage = new FinalPage(driver);
        Assert.assertEquals(finalPage.getTitle(), "CHECKOUT: COMPLETE!");
        Assert.assertEquals(finalPage.orderMsg(), "THANK YOU FOR YOUR ORDER");
        Reporter.log("Order has been placed successfully <br/>", true);

        //logout
        finalPage.logout();
        Reporter.log("Loggedout from application successfully <br/>", true);

    }


    @DataProvider(name = "credentials")
    public Object[][] getCred() throws Exception {
        String loginData[][] = ExcelUtil.getExcelData("./src/test/resources/testData/loginTestData.xlsx", "loginSheet");
        return loginData;
    }

    @DataProvider(name = "userInfo")
    public Object[][] getUserInfo() throws Exception {
        String loginData[][] = ExcelUtil.getExcelData("./src/test/resources/testData/loginTestData.xlsx", "userInfo");
        return loginData;
    }

}


